/**
 * 
 */
package com.cg.mvc.service;

import java.util.List;

import com.cg.mvc.dto.Emp;

/**
 * @author smitkuma
 *
 */
public interface EmpService {

	Emp save(Emp emp);

	Emp update(Emp emp);

	void delete(int id);

	Emp getEmpById(int id);

	List<Emp> getEmployees();

}
