package com.pdw.entities;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("1-MBI");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
////		//create a new department
//		Department department = new Department();
//		department.setId(10);
//		department.setName("Sales");
////		//em.persist(department);
////		//create two instances of employees
//		Employee e1 = new Employee();
//		e1.setId(1001);
//		e1.setName("Priya");
//		e1.setSalary(4500);
//		e1.setDepartment(department);
//		Employee e2 = new Employee();
//		e2.setId(1002);
//		e2.setName("Dinesh");
//		e2.setSalary(5500);
//		e2.setDepartment(department);
//		List<Employee> employees=new ArrayList<Employee>();
//		employees.add(e1);
//		employees.add(e2);
//		department.setEmployees(employees);
//		em.persist(department);
	//	Employee emp = em.find(Employee.class, arg1);
		TypedQuery<Department> q = em.createQuery("Select e from Department e", Department.class);
		 //q.setParameter("D_id", 10);
	
		List<Department> emp = q.getResultList();
Iterator<Department> itr=		emp.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next().getEmployees());
	}
		em.getTransaction().commit();
		
	}
}
