package com.odigos.bank.exceptions;

public class InsufficientBalance extends Exception {
	public InsufficientBalance(String message) {
		super(message);
	}
}
