package com.odigos.bank.ui;

import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import com.odigos.bank.exceptions.AccountNotFound;
import com.odigos.bank.model.Account;
import com.odigos.bank.model.Transaction;
import com.odigos.bank.service.BankService;
import com.odigos.bank.service.BankServiceImpl;

public class BankClient {

	public static void main(String[] args) throws SQLException {
		BankService service = new BankServiceImpl();
		int accountNo = 1000;
		String accountHolderName = null;
		float balance = 0.0f;
		String branch = null;
		long contactNo = 0;
		Account account = null;
		while (true) {

			System.out.println("*************XYZ Bank App**************");
			System.out.println("1) create account");
			System.out.println("2) view account details");
			System.out.println("3) withdraw");
			System.out.println("4) deposit");
			System.out.println("5) fund transfer");
			System.out.println("6) print transactions");
			Scanner scan = new Scanner(System.in);
			int option = scan.nextInt();
			switch (option) {
			case 1:
				 accountNo = new Random().nextInt(9000) + 1000;
				System.out.println("Enter Details To create Account");
				System.out.println("Enter Your Name");
				accountHolderName = scan.next();
				System.out.println("Enter Balance");
				balance = scan.nextFloat();
				System.out.println("Enter Your Branch");
				branch = scan.next();
				System.out.println("Enter Your Contact");
				contactNo = scan.nextLong();
				account = new Account(accountNo, accountHolderName, balance, branch, contactNo);
				String result = service.createAccount(account);
				System.out.println(result + " " + accountNo);
				break;
			case 2:
				System.out.println("Enter Accountno to view Account details");
				accountNo = scan.nextInt();
				Account accountDetails;
				try {
					accountDetails = service.viewAccountDetails(accountNo);
					System.out.println(accountDetails);
				} catch (SQLException e) {
					System.out.println("Some DB Exception");
				} catch (AccountNotFound e) {
					System.out.println("Invalid Account Number");
				}

				break;
			case 3:
				System.out.println("Enter Accountno to Withdraw ");
				accountNo = scan.nextInt();
				System.out.println("Enter Amount to withdraw");
				balance = scan.nextFloat();
				float updatedBalance;
				try {
					updatedBalance = service.withdrawAmount(accountNo, balance);
					System.out.println("Withdrawl is completed and updated balance" + updatedBalance);
				} catch (SQLException e1) {
					e1.printStackTrace();
				} catch (AccountNotFound e1) {
					System.out.println("Invalid Account Number!!!");
				}

				break;
			case 4:
				System.out.println("Enter Accountno to Deposit ");
				accountNo = scan.nextInt();
				System.out.println("Enter Amount to Deposit");
				balance = scan.nextFloat();
				try {
					updatedBalance = service.depositAmount(accountNo, balance);
					System.out.println("After Deposit the Updated balance" + updatedBalance);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (AccountNotFound e1) {
					System.out.println("Invalid Account Number!!!");
				}

				break;
			case 5:
				System.out.println("Enter From Accountno to Transfer ");
				int fromAccountNo = scan.nextInt();
				System.out.println("Enter To Accountno for Transfer ");
				int toAccountNo = scan.nextInt();
				System.out.println("Enter Amount to transfer");
				balance = scan.nextFloat();
				try {
					updatedBalance = service.fundTransfer(fromAccountNo, toAccountNo, balance);
					System.out.println("After FundTransfer the Updated From AccountBalance" + updatedBalance);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (AccountNotFound e) {
					System.out.println("Invalid Account Number!!!");
				}

				break;
			case 6:
				Set<Transaction> transactions;
				try {
					transactions = service.printTransactions();
					for (Transaction tran : transactions) {
						System.out.println(tran);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (AccountNotFound e) {
					System.out.println("Invalid Account No");
				}
				
				break;
			default:
				scan.close();
				System.out.println("Thank You !!!");
				System.exit(0);
				break;
			}

		}
	}

}
