package com.odigos.bank.service;

import java.sql.SQLException;
import java.util.Set;

import com.odigos.bank.dao.BankDAO;
import com.odigos.bank.dao.BankDAOImpl;
import com.odigos.bank.exceptions.AccountNotFound;
import com.odigos.bank.model.Account;
import com.odigos.bank.model.Transaction;

public class BankServiceImpl implements BankService {

	BankDAO dao = new BankDAOImpl();

	@Override
	public String createAccount(Account account) throws SQLException {

		return dao.createAccount(account);
	}

	@Override
	public Account viewAccountDetails(int accountNo) throws SQLException, AccountNotFound {

		return dao.viewAccountDetails(accountNo);
	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw) throws SQLException, AccountNotFound {

		return dao.withdrawAmount(accountNo, amountToWithdraw);
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) throws SQLException, AccountNotFound {

		return dao.depositAmount(accountNo, amountToDeposit);
	}

	@Override
	public float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer) throws SQLException, AccountNotFound {

		return dao.fundTransfer(fromAccountNo, toAccountNo, amountToTransfer);
	}

	@Override
	public Set<Transaction> printTransactions() throws SQLException, AccountNotFound {

		return dao.printTransactions();
	}

}
