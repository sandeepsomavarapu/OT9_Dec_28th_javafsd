package com.odigos.bank.service;

import java.sql.SQLException;
import java.util.Set;

import com.odigos.bank.exceptions.AccountNotFound;
import com.odigos.bank.model.Account;
import com.odigos.bank.model.Transaction;

public interface BankService {

	public abstract String createAccount(Account account) throws SQLException;

	public abstract Account viewAccountDetails(int accountNo) throws SQLException, AccountNotFound;

	public abstract float withdrawAmount(int accountNo, float amountToWithdraw) throws SQLException, AccountNotFound;

	public abstract float depositAmount(int accountNo, float amountToDeposit) throws SQLException, AccountNotFound;

	public abstract float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer) throws SQLException, AccountNotFound;

	public abstract Set<Transaction> printTransactions() throws SQLException, AccountNotFound;
}
