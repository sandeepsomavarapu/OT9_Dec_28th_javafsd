package com.ot9.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmp {

	public static void main(String[] args) {
		// BeanFactory factory=new XmlBeanFactory(new
		// ClassPathResource("springconfig.xml"));
		ApplicationContext factory = new ClassPathXmlApplicationContext("springconfig.xml");
		Employee emp = (Employee) factory.getBean("emp");
		System.out.println(emp);
	}

}
