package com.ot9.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class TestEmp {

	public static void main(String[] args) {
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("springconfig.xml"));
		Employee emp=(Employee) factory.getBean("emp");
		System.out.println(emp);
	}

}
