package com.odigos.bank.exceptions;

public class InsufficientBalance {

}
