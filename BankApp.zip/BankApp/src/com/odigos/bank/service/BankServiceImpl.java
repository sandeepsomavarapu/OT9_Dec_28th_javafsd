package com.odigos.bank.service;

import java.util.Set;

import com.odigos.bank.dao.BankDAO;
import com.odigos.bank.dao.BankDAOImpl;
import com.odigos.bank.model.Account;
import com.odigos.bank.model.Transaction;

public class BankServiceImpl implements BankService {

	BankDAO dao = new BankDAOImpl();

	@Override
	public String createAccount(Account account) {

		return dao.createAccount(account);
	}

	@Override
	public Account viewAccountDetails(int accountNo) {

		return dao.viewAccountDetails(accountNo);
	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw) {

		return dao.withdrawAmount(accountNo, amountToWithdraw);
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) {

		return dao.depositAmount(accountNo, amountToDeposit);
	}

	@Override
	public float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer) {

		return dao.fundTransfer(fromAccountNo, toAccountNo, amountToTransfer);
	}

	@Override
	public Set<Transaction> printTransactions() {

		return dao.printTransactions();
	}

}
