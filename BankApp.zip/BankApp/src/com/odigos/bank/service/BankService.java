package com.odigos.bank.service;

import java.util.Set;

import com.odigos.bank.model.Account;
import com.odigos.bank.model.Transaction;

public interface BankService {

	public abstract String createAccount(Account account);

	public abstract Account viewAccountDetails(int accountNo);

	public abstract float withdrawAmount(int accountNo, float amountToWithdraw);

	public abstract float depositAmount(int accountNo, float amountToDeposit);

	public abstract float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer);

	public abstract Set<Transaction> printTransactions();
}
