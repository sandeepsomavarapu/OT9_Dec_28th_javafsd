package com.odigos.bank.model;

import java.util.Date;

public class Transaction {
	private int transactionId;
	private String transactionType;
	private Date timeOfTransaction;
	private float updateBalance;
	private float balance;
	private int fromAccountNo;
	private int toAccountNo;

	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	public Transaction(int transactionId, String transactionType, Date timeOfTransaction, float updateBalance,
			float balance, int fromAccountNo, int toAccountNo) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.timeOfTransaction = timeOfTransaction;
		this.updateBalance = updateBalance;
		this.balance = balance;
		this.fromAccountNo = fromAccountNo;
		this.toAccountNo = toAccountNo;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTimeOfTransaction() {
		return timeOfTransaction;
	}

	public void setTimeOfTransaction(Date timeOfTransaction) {
		this.timeOfTransaction = timeOfTransaction;
	}

	public float getUpdateBalance() {
		return updateBalance;
	}

	public void setUpdateBalance(float updateBalance) {
		this.updateBalance = updateBalance;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public int getToAccountNo() {
		return toAccountNo;
	}

	public void setToAccountNo(int toAccountNo) {
		this.toAccountNo = toAccountNo;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", timeOfTransaction=" + timeOfTransaction + ", updateBalance=" + updateBalance + ", balance="
				+ balance + ", fromAccountNo=" + fromAccountNo + ", toAccountNo=" + toAccountNo + "]";
	}

}
