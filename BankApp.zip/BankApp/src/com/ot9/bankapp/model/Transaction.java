package com.ot9.bankapp.model;

import java.util.Date;

public class Transaction {
	private int transId;
	private float balance;
	private float updatedBalance;
	private String typeOfTransaction;
	private Date dateOfTransaction;
	private int fromAccountNo;
	private int toAccountNo;

	public String getTypeOfTransaction() {
		return typeOfTransaction;
	}

	public void setTypeOfTransaction(String typeOfTransaction) {
		this.typeOfTransaction = typeOfTransaction;
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public float getUpdatedBalance() {
		return updatedBalance;
	}

	public void setUpdatedBalance(float updatedBalance) {
		this.updatedBalance = updatedBalance;
	}

	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public int getFromAccountNo() {
		return fromAccountNo;
	}

	public void setFromAccountNo(int fromAccountNo) {
		this.fromAccountNo = fromAccountNo;
	}

	public int getToAccountNo() {
		return toAccountNo;
	}

	public void setToAccountNo(int toAccountNo) {
		this.toAccountNo = toAccountNo;
	}

	public Transaction(int transId, float balance, float updatedBalance, String typeOfTransaction,
			Date dateOfTransaction, int fromAccountNo, int toAccountNo) {
		super();
		this.transId = transId;
		this.balance = balance;
		this.updatedBalance = updatedBalance;
		this.typeOfTransaction = typeOfTransaction;
		this.dateOfTransaction = dateOfTransaction;
		this.fromAccountNo = fromAccountNo;
		this.toAccountNo = toAccountNo;
	}

	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", balance=" + balance + ", updatedBalance=" + updatedBalance
				+ ", typeOfTransaction=" + typeOfTransaction + ", dateOfTransaction=" + dateOfTransaction
				+ ", fromAccountNo=" + fromAccountNo + ", toAccountNo=" + toAccountNo + "]";
	}

	public Transaction() {
		// TODO Auto-generated constructor stub
	}

}
