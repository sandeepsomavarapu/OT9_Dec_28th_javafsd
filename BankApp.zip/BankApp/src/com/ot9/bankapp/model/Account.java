package com.ot9.bankapp.model;

public class Account {
	private int accountNo;
	private String accountHolderName;
	private float accountbalance;
	private long contact;
	private String address;

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public float getAccountbalance() {
		return accountbalance;
	}

	public void setAccountbalance(float accountbalance) {
		this.accountbalance = accountbalance;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(int accountNo, String accountHolderName, float accountbalance, long contact, String address) {
		super();
		this.accountNo = accountNo;
		this.accountHolderName = accountHolderName;
		this.accountbalance = accountbalance;
		this.contact = contact;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountHolderName=" + accountHolderName + ", accountbalance="
				+ accountbalance + ", contact=" + contact + ", address=" + address + "]";
	}

}
