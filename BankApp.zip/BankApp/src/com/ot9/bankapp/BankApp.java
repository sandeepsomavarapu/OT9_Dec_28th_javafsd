package com.ot9.bankapp;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.ot9.bankapp.models.Account;
import com.ot9.bankapp.models.Transaction;

public class BankApp {

	public static void main(String[] args) {// collections
		HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();// database
		HashMap<Integer, Transaction> transactions = new HashMap<Integer, Transaction>();// database
		int accountNo;
		String accountHolderName;
		float accountBalnce;
		String accountBranch;
		long contact;
		Account accountDetails;
		int transactionId = 1000;
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("**************Bank Application************");
			System.out.println("1)Create Account");
			System.out.println("2)View Account Details");
			System.out.println("3)Withdraw");
			System.out.println("4)Deposit");
			System.out.println("5)FundTransfer");
			System.out.println("6)Print Transactions ");
			System.out.println("7)Exit");
			int option = scan.nextInt();// ui code

			switch (option) {
			case 1:

				System.out.println("Enter Details To Create Account :");
				System.out.println("Enter Your Name ");
				accountHolderName = scan.next();
				System.out.println("Enter Your Amount ");
				accountBalnce = scan.nextFloat();
				System.out.println("Enter Your Branch ");
				accountBranch = scan.next();
				System.out.println("Enter Your Contact ");
				contact = scan.nextLong();
				accountNo = (int) (contact - 100000);
				Account account = new Account(accountNo, accountHolderName, accountBalnce, accountBranch, contact);
				accounts.put(accountNo, account);
				System.out.println("Account Created Successfully With AccNo: " + accountNo);
				break;
			case 2:
				System.out.println("Enter You Account No:");
				accountNo = scan.nextInt();
				accountDetails = accounts.get(accountNo);
				System.out.println(accountDetails);
				break;
			case 3:
				System.out.println("Enter You Account No to withdraw:");
				accountNo = scan.nextInt();
				System.out.println("Enter Your Amount ");
				float amountToWithdraw = scan.nextFloat();
				accountDetails = accounts.get(accountNo);
				float exsisitngBalance = accountDetails.getAccountBalnce();
				float updatedBalance = exsisitngBalance - amountToWithdraw;
				accountDetails.setAccountBalnce(updatedBalance);
				Transaction transaction = new Transaction(++transactionId, "withdraw", updatedBalance, accountNo, 0,
						new Date());
				transactions.put(transactionId, transaction);
				System.out.println("Amount withdrawl done and updated balance :" + updatedBalance);
				break;
			case 4:
				System.out.println("Enter You Account No to Deposit:");
				accountNo = scan.nextInt();
				System.out.println("Enter Your Amount ");
				float amountToDeposit = scan.nextFloat();
				accountDetails = accounts.get(accountNo);
				exsisitngBalance = accountDetails.getAccountBalnce();
				updatedBalance = exsisitngBalance + amountToDeposit;
				accountDetails.setAccountBalnce(updatedBalance);
				Transaction transaction1 = new Transaction(++transactionId, "deposit", updatedBalance, accountNo, 0,
						new Date());
				transactions.put(transactionId, transaction1);
				System.out.println("Amount Deposit done and updated balance :" + updatedBalance);
				break;
			case 5:
				System.out.println("Enter From Account No for Transfer:");
				int fromAccountNo = scan.nextInt();
				System.out.println("Enter To Account No for Transfer:");
				int toAccountNo = scan.nextInt();
				System.out.println("Enter Your Amount to transfer ");
				float amountToTransfer = scan.nextFloat();

				Account fromAccountDetails = accounts.get(fromAccountNo);
				float fromAccountBalance = fromAccountDetails.getAccountBalnce();
				Account toAccountDetails = accounts.get(toAccountNo);
				float toAccountBalance = toAccountDetails.getAccountBalnce();

				float updatedFromAccountBalance = fromAccountBalance - amountToTransfer;
				fromAccountDetails.setAccountBalnce(updatedFromAccountBalance);
				accounts.put(fromAccountNo, fromAccountDetails);
				float updatedToAccountBalance = toAccountBalance + amountToTransfer;
				toAccountDetails.setAccountBalnce(updatedToAccountBalance);
				accounts.put(toAccountNo, toAccountDetails);
				Transaction transaction2 = new Transaction(++transactionId, "fundtransfer", updatedFromAccountBalance,
						fromAccountNo, toAccountNo, new Date());
				transactions.put(transactionId, transaction2);
				System.out.println("Updated From Account Balance :" + updatedFromAccountBalance);
				break;
			case 6:
				Set<Integer> set = transactions.keySet();
				Iterator<Integer> itr = set.iterator();
				while (itr.hasNext()) {
					int transId = itr.next();
					System.out.println(transactions.get(transId));

				}
				break;
			case 7:
				scan.close();
				System.out.println("Thank You !!!");
				System.exit(0);
				break;
			}
		}

	}

}
