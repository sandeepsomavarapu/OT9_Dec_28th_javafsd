package com.ot9.bankapp.models;

public class Account {
	private int accountNo;
	private String accountHolderName;
	private float accountBalnce;
	private String accountBranch;
	private long contact;

	@Override
	public String toString() {
		return "[accountNo=" + accountNo + ", accountHolderName=" + accountHolderName + ", accountBalnce="
				+ accountBalnce + ", accountBranch=" + accountBranch + ", contact=" + contact + "]";
	}

	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(int accountNo, String accountHolderName, float accountBalnce, String accountBranch, long contact) {
		super();
		this.accountNo = accountNo;
		this.accountHolderName = accountHolderName;
		this.accountBalnce = accountBalnce;
		this.accountBranch = accountBranch;
		this.contact = contact;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public float getAccountBalnce() {
		return accountBalnce;
	}

	public void setAccountBalnce(float accountBalnce) {
		this.accountBalnce = accountBalnce;
	}

	public String getAccountBranch() {
		return accountBranch;
	}

	public void setAccountBranch(String accountBranch) {
		this.accountBranch = accountBranch;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

}
