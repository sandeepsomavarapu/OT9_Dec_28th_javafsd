package com.ot9.bankapp;

import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import com.ot9.bankapp.model.Account;
import com.ot9.bankapp.model.Transaction;

public class Client {

	public static void main(String[] args) {
		int accountNo;
		String accountHolderName;
		float accountbalance;
		long contact;
		String address;
		int transId = 1000;
		HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();
		HashMap<Integer, Transaction> transactions = new HashMap<Integer, Transaction>();
		Scanner scan = new Scanner(System.in);
		System.out.println("*****************X Bank Application****************");
		while (true) {
			System.out.println("1)Create Account\r\n" + "2)Display Account Info\r\n" + "3)Withdraw\r\n"
					+ "4)Deposit\r\n" + "5)FundTransfer\r\n" + "6)Statement\r\n" + "7)Statement Between The Dates \r\n"
					+ "8)Exit");
			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("******Enter Account Details***********");
				System.out.println("Enter Your Name ");
				accountHolderName = scan.next();
				System.out.println("Enter The Amount ");
				accountbalance = scan.nextFloat();
				System.out.println("Enter The ContactNumber ");
				contact = scan.nextLong();
				System.out.println("Enter Your Address ");
				address = scan.next();
				accountNo = (int) (contact - 200000);
				Account account = new Account(accountNo, accountHolderName, accountbalance, contact, address);
				accounts.put(accountNo, account);
				System.out.println("Account Created Successfully With Acc No :" + accountNo);
				break;
			case 2:
				System.out.println("Enter The Account Number ");
				accountNo = scan.nextInt();
				account = accounts.get(accountNo);
				System.out.println(account);
				break;
			case 3:
				System.out.println("Enter The Account Number To Withdraw ");
				accountNo = scan.nextInt();
				account = accounts.get(accountNo);
				System.out.println("Enter The Amount To withdraw");
				float amountToWithdraw = scan.nextFloat();
				float balance = account.getAccountbalance();
				float updatedBalance = balance - amountToWithdraw;
				account.setAccountbalance(updatedBalance);
				accounts.put(accountNo, account);
				Transaction trans = new Transaction(++transId, balance, updatedBalance, "WITHDRAW", new Date(),
						accountNo, 0);
				transactions.put(transId, trans);
				System.out.println("Withdrawl Completed Successfully and Updated Balance :" + updatedBalance);
				break;
			case 4:
				System.out.println("Enter The Account Number To Deposit ");
				accountNo = scan.nextInt();
				account = accounts.get(accountNo);
				System.out.println("Enter The Amount To Deposit");
				float amountToDeposit = scan.nextFloat();
				balance = account.getAccountbalance();
				updatedBalance = balance + amountToDeposit;
				account.setAccountbalance(updatedBalance);
				accounts.put(accountNo, account);
				Transaction trans1 = new Transaction(++transId, balance, updatedBalance, "DEPOSIT", new Date(),
						accountNo, 0);
				transactions.put(transId, trans1);
				System.out.println("Deposit Completed Successfully and Updated Balance :" + updatedBalance);
				break;
			case 5:
				System.out.println("Enter The From Account Number To Transfer ");
				int fromAccountNo = scan.nextInt();
				Account fromAccount = accounts.get(fromAccountNo);
				System.out.println("Enter The To  Account Number To Transfer ");
				int toAccountNo = scan.nextInt();
				Account toAccount = accounts.get(toAccountNo);
				System.out.println("Enter The Amount To transfer");
				float amountToTransfer = scan.nextFloat();
				 balance=fromAccount.getAccountbalance();
				float updatedFromAccountBalance = fromAccount.getAccountbalance() - amountToTransfer;
				float updatedToAccountBalance = toAccount.getAccountbalance() + amountToTransfer;
				fromAccount.setAccountbalance(updatedFromAccountBalance);
				toAccount.setAccountbalance(updatedToAccountBalance);
				accounts.put(fromAccountNo, fromAccount);
				accounts.put(toAccountNo, toAccount);
				Transaction trans2 = new Transaction(++transId, balance, updatedFromAccountBalance, "Transfer", new Date(),
						fromAccountNo, toAccountNo);
				transactions.put(transId, trans2);
				System.out.println(
						"Balance Transfer Completed..After Transfer Updated Balance: " + updatedFromAccountBalance);
				break;
			case 6:
				Set<Integer> tran=transactions.keySet();
				
				for(int tranid:tran)
				{
					Transaction tras=transactions.get(tranid);
					System.out.println(tras);
				}

				break;
			case 7:

				break;
			default:
				System.out.println("Thank You !!!");
				System.exit(0);
				break;
			}

		}
	}

}
