package com.ot9.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestEmployee {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("mysql");
		EntityManager em = factory.createEntityManager();
		// persist()-->insert,merge()-->update,remove()-->delete,find-->fetch
		em.getTransaction().begin();
//		Employee emp = new Employee(123, "mahesh", 23000, "developer");
//		em.persist(emp);
		Employee emp = em.find(Employee.class, 123);
		System.out.println(emp);
//		emp.setEmpDesg("trainer");
//		em.merge(emp);
		em.remove(emp);
		em.getTransaction().commit();
		System.out.println("inserted");
	}

}
